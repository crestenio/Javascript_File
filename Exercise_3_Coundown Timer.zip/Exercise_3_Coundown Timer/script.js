let counter = 10;
setInterval(function(){
      if(counter <= 0){
            document.getElementById("image").setAttribute("src", "https://iheartcraftythings.com/wp-content/uploads/2021/05/How-to-Draw-Rocket-%E2%80%93-Featured-Image.jpg");
            clearInterval(countDownTimer);
      }
      let newDiv = document.createElement('div');
      newDiv.setAttribute('id', 'countDownBox')
      newDiv.innerHTML = `${counter}`
      let countContainer = document.getElementById("container-countdown")
countContainer.appendChild(newDiv)
counter -= 1;
}, 1000);
console.log("left", counter)