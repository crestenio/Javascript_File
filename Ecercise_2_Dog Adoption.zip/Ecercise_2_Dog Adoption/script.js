window.onload = function onload(){

    const containerDiv = document.getElementById("container");
  let innerHTML = "";


    function dogYears(humanAge) {
        var dogAge = parseInt(humanAge + 7);
        return dogAge;
    }
    let dogs = [
        {
          "name" : "Sushi",
          "age" : dogYears(0),
          "toys" : "bone, water, bottle",
          "image" : "./images/dog0.png"
        },
        {
          "name" : "Dosan",
          "age" : dogYears(7),
          "toys" : "ball, shoes",
          "image" : "./images/dog1.png"
        },
        {
          "name" : "Moonchin",
          "age" : dogYears(7),
          "toys" : "ducklings, tabo",
          "image" : "./images/dog2.png"
        },
    ];

    for (let dog of dogs) {
        innerHTML += `
        <div class="dog">
            <p class="dog1name"> Name : ${dog.name}</p>
            <p class="dog1age"> Age : Your doggie is ${dog.age} years old in dog years!</p>
            <img src="${dog.image}">
            <p class="dog1toys">fave toys : ${dog.toys}</p>
        </div>
        `;
    }
  containerDiv.innerHTML = innerHTML
}