function tempConverter(){
    let number = document.getElementById("celcius");
    number = parseFloat(number.value);
    Fahrenheit = (number * 1.8) + 32 + "°F";
    document.getElementById("fahrenheit").innerHTML = Fahrenheit;
}