//product gallery swiper script //

const swiper = new Swiper(".swiper", {
  autoplay: {
    delay: 3000,
    disableOnInteraction: false,
  },
  loop: true,
  pagination: {
    el: ".swiper-pagination",
    clickable: true,
  },
  navigation: {
    nextEl: ".swiper-button-next",
    prevEl: ".swiper-button-prev",
  },
});

// script for testimonial slider//

var slide = document.getElementById("slide");
var upArrow = document.getElementById("upArrow");
var downArrow = document.getElementById("downArrow");

let x = 0;

upArrow.onclick = function () {
  if (x > "-900") {
    x = x - 300;
    slide.style.top = x + "px";
  }
};
downArrow.onclick = function () {
  if (x < 0) {
    x = x + 300;
    slide.style.top = x + "px";
  }
};

//send email script//

//function sendEmail() {
// Email.send({
//   Host: "smtp.gmail.com",
//   Username: "crestenio@gmail.com",
//    Password: "#Bimbel2014",
//    To: "crestenio@gmail.com",
//    From: document.getElementById("email").value,
//    Subject: "New Contact Form Inquiry",
//   Body:
//      "Name: " +
//     document.getElementById("name").value +
//     "<br> Email: " +
//      document.getElementById("email").value +
//      "<br> Message: " +
//     document.getElementById("message").value,
//  }).then((message) => {
//    const msg = document.getElementById("message");
//   msg.innerHTML = "Message sent successfully!";
//    setTimeout(function () {
//     msg.innerHTML = "";
//    }, 5000);
//  });
//}

// contact form validation///

var nameError = document.getElementById("name-error");
var emailError = document.getElementById("email-error");
var messageError = document.getElementById("message-error");
var submitError = document.getElementById("submit-error");

function validateName(){
    var name = document.getElementById("contact-name").value;

    if(name.length == 0){
        nameError.innerHTML = 'Name is required';
        return false;
    }
    if(!name.match(/^[A-Za-z]*\s{1}[A-Za-z]*$/)){
        nameError.innerHTML = 'Write full name';
        return false;
    }
    nameError.innerHTML = '<i class="fas fa-check-circle"></i>';
    return true;
}

function validateEmail(){
    var email = document.getElementById("contact-email").value;

    if(email.length == 0){
        emailError.innerHTML = "Email is required";
        return false;
    }
    if(!email.match(/^[A-Za-z\._\-[0-9]*[@][A-za-z]*[\.][a-z]{2,4}$/)){
        emailError.innerHTML = "Invalid email";
        return false
    }
    emailError.innerHTML = '<i class="fas fa-check-circle"></i>';
    return true;
}

function validateMessage(){
    var message = document.getElementById("contact-message").value;
    var required = 30;
    var left = required - message.length;

    if(left > 0){
        messageError.innerHTML = left + ' more characters required';
        return false;
    }
    messageError.innerHTML = '<i class="fas fa-check-circle"></i>';
    return true;
}

function validateForm(){
    if(!validateName() || !validateEmail() || !validateMessage()){
        submitError.style.display = 'block';
        submitError.innerHTML = 'Please fix error to submit';
        setTimeout(function(){submitError.style.display = 'none';}, 3000);
        return false;
    }
}

// FAQ script//

const faqs = document.querySelectorAll(".faq");
faqs.forEach((faq) => {
  faq.addEventListener("click", () => {
    faq.classList.toggle("active");
  });
});

//Script for side menu smaller screen//

var sidemenu = document.getElementById("sidemenu");

function openmenu() {
  sidemenu.style.right = "0";
}

function closemenu() {
  sidemenu.style.right = "-200px";
}
