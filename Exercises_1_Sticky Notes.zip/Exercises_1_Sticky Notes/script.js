const colors = ['red','orange','yellow', 'green', 'blue', 'violet'];
let count = 0;

document.getElementById("add-note").addEventListener("click", () => {
    let add = document.createElement("div");
    add.setAttribute("class", "page");
    add.innerHTML = document.getElementById("note").value;
    add.style.background = colors[count++ % colors.length];
    document.getElementById("container").appendChild(add);
});